#include <stdio.h>
#include <string.h>

const int KSize = 1024 * 1024;

int main(int argc, char* argv[])
{

    int ch = 0;
    if (argc > 1)
        ch = *argv[1];
    char filebuf[KSize];
    memset(filebuf, ch, KSize);

    FILE* pFile;
    char filename[256] = {0};
    filename[0] = ch;
    if (argc == 1)
        filename[0] = '0';

    for (int f = 0 ; f != 1024 ; ++f) {   // 测试文件只写 5个 512M的文件
        sprintf(filename + 1, "%04d" , f);
        pFile = fopen(filename , "wb");

        for (int i = 0 ; i != 512; ++i) {
            ch = fwrite(filebuf , 1 , sizeof(filebuf) , pFile);
            if (ch == 0) {
                while (ch = fwrite(filebuf , 1 , 1024 , pFile))
                    ;
                printf("不能再写了\n最后一个文件名%s\n", filename);
                return 88;
            }
        }
        printf("输出文件名: %s\n", filename);
        fclose(pFile);

    }
    return 0;
}
