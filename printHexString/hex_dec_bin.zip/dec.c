#include <stdio.h>
#include <stdlib.h>

void hexToBinary(unsigned int hexValue, int groupSize) 
{
  unsigned int mask = 0x80000000; // 32位掩码，用于逐位检查十六进制值
  printf("Bin: ");
  for (int i = 0; i < 32; i++) {
    // 使用逻辑与操作符检查位是否为1，并打印相应的0或1
    printf("%d", (hexValue & mask) ? 1 : 0);

    // 将掩码右移一位，检查下一个位
    mask >>= 1;

    // 如果是groupSize的倍数且不是最后一位，则输出一个空格
    if ((i + 1) % groupSize == 0 && i != 31)  printf(" ");
  }
  puts("\n");
}

int main(int argc, char *argv[]) 
{
  if (argc < 2) {
    printf("Usage: dec <value> [value2]\n");
    return 1;
  }

  for (int i = 1; i != argc; i++) {
    unsigned int Value = strtol(argv[i], NULL, 10);
    printf("Hex: 0x%X\tDec: %s\n", Value, argv[i]);

    int groupSize = 4;
    hexToBinary(Value, groupSize);
  }

  return 0;
}
