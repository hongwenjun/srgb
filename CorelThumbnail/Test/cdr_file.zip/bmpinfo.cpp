#include <iostream>
#include <stdio.h>
#include <windows.h>

using namespace std;

#pragma pack(pop)
#pragma pack(push,2)
typedef struct myBITMAPFILEHEADER {
	WORD	bfType;
	DWORD	bfSize;
	WORD	bfReserved1;
	WORD	bfReserved2;
	DWORD	bfOffBits;
} myBITMAPFILEHEADER;
#pragma pack(pop)

int main()
{
    myBITMAPFILEHEADER my_head;
    BITMAPFILEHEADER bmp_head;
    BITMAPINFOHEADER bmp_info;

    FILE* bf = fopen("test.bmp" , "rb");

    fread(&bmp_head, 1, sizeof(bmp_head), bf);
    fread(&bmp_info, 1, sizeof(bmp_info), bf);

    size_t pos = ftell(bf);

    cout << sizeof(my_head) << endl;

    cout << sizeof(bmp_head) << endl;
    cout << sizeof(bmp_info) << endl;

    cout << pos << endl;


    return 0;
}
